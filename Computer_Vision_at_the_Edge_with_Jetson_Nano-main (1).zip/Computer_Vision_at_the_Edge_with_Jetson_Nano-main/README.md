# Computer_Vision_at_the_Edge_with_Jetson_Nano
Two Days free Hands on Training in Computer Vision at the Edge with Jetson Nano scheduled on 5th &amp; 6th of Nov 2020 from 4.00 PM till 6.00 PM
